// ===== 關卡資料 =====
const allLevels = {
  beginner: [
    {
      id: 1, title: "集合太空人", astronautCount: 3, properties: ["justify-content"],
      target: { "justify-content": "center" },
      description: "太空人散落在救援艙中，使用 justify-content 將他們集中到中間！",
      hint: "justify-content 控制項目在「主軸」（水平方向）的位置。想讓項目置中，試試哪個值？",
      tip: "💡 提示：center 代表「中間」的意思",
      learnedText: "justify-content: center 讓項目水平置中"
    },
    {
      id: 2, title: "靠左集合", astronautCount: 3, properties: ["justify-content"],
      target: { "justify-content": "flex-start" },
      description: "讓太空人全部靠左邊集合，準備出發！",
      hint: "flex-start 是 flexbox 的「起點」，預設情況下就是左邊。",
      tip: "💡 flex-start = 彈性盒子的起點 = 左邊",
      learnedText: "justify-content: flex-start 讓項目靠左對齊"
    },
    {
      id: 3, title: "緊急撤離", astronautCount: 4, properties: ["justify-content"],
      target: { "justify-content": "flex-end" },
      description: "警報響起！快將所有太空人集中到救援艙的右側出口！",
      hint: "與 flex-start 相反，flex-end 代表「終點」，就是右邊。",
      tip: "💡 flex-end = 彈性盒子的終點 = 右邊",
      learnedText: "justify-content: flex-end 讓項目靠右對齊"
    },
    {
      id: 4, title: "平均站位", astronautCount: 3, properties: ["justify-content"],
      target: { "justify-content": "space-between" },
      description: "讓太空人平均分散，第一個在最左邊，最後一個在最右邊！",
      hint: "space-between 會把第一個和最後一個項目推到兩端，中間的平均分布。",
      tip: "💡 between = 「之間」，空間分布在項目之間",
      learnedText: "justify-content: space-between 兩端對齊，中間平均"
    },
    {
      id: 5, title: "均勻分布", astronautCount: 3, properties: ["justify-content"],
      target: { "justify-content": "space-evenly" },
      description: "讓所有間距完全相等，包含左右兩邊！",
      hint: "space-evenly 讓所有間隙都相等，包含容器邊緣到項目的距離。",
      tip: "💡 evenly = 「均勻地」，所有空間完全相等",
      learnedText: "justify-content: space-evenly 所有間距相等"
    },
    {
      id: 6, title: "垂直置中", astronautCount: 3, properties: ["align-items"],
      target: { "align-items": "center" },
      description: "太空人漂浮在不同高度，讓他們在同一水平線上對齊！",
      hint: "align-items 控制「交叉軸」（垂直方向）的對齊。center 會讓它們垂直置中。",
      tip: "💡 align = 對齊，items = 項目們，交叉軸上對齊項目",
      learnedText: "align-items: center 讓項目垂直置中"
    },
    {
      id: 7, title: "頂部集合", astronautCount: 4, properties: ["align-items"],
      target: { "align-items": "flex-start" },
      description: "讓太空人全部對齊到頂部！",
      hint: "在交叉軸（垂直方向）上，flex-start 代表頂部。",
      tip: "💡 交叉軸的 flex-start = 頂部",
      learnedText: "align-items: flex-start 讓項目靠頂對齊"
    },
    {
      id: 8, title: "降落準備", astronautCount: 4, properties: ["align-items"],
      target: { "align-items": "flex-end" },
      description: "救援艙準備降落，讓太空人對齊到底部站穩！",
      hint: "在交叉軸上，flex-end 代表底部。",
      tip: "💡 交叉軸的 flex-end = 底部",
      learnedText: "align-items: flex-end 讓項目靠底對齊"
    },
    {
      id: 9, title: "環繞分布", astronautCount: 4, properties: ["justify-content"],
      target: { "justify-content": "space-around" },
      description: "讓每個太空人左右兩邊都有相等的空間！",
      hint: "space-around 讓每個項目周圍的空間相等，但邊緣空間是中間的一半。",
      tip: "💡 around = 「周圍」，每個項目周圍空間相等",
      learnedText: "justify-content: space-around 項目周圍空間相等"
    },
    {
      id: 10, title: "完美置中", astronautCount: 2, properties: ["justify-content", "align-items"],
      target: { "justify-content": "center", "align-items": "center" },
      description: "初級最終關！讓太空人在救援艙正中央！",
      hint: "同時使用 justify-content 和 align-items，兩個都設為 center！",
      tip: "💡 水平置中 + 垂直置中 = 正中央",
      learnedText: "組合兩個屬性可以實現完美置中！"
    }
  ],
  intermediate: [
    {
      id: 1, title: "垂直編隊", astronautCount: 3, properties: ["flex-direction"],
      target: { "flex-direction": "column" },
      description: "改變救援艙的方向，讓太空人垂直排列！",
      hint: "flex-direction 改變主軸方向。column 表示「列」，就是垂直排列。",
      tip: "💡 column = 列 = 垂直排列（像報紙的欄位）",
      learnedText: "flex-direction: column 垂直排列項目"
    },
    {
      id: 2, title: "反向撤離", astronautCount: 4, properties: ["flex-direction"],
      target: { "flex-direction": "row-reverse" },
      description: "太空人需要反向排列撤離，1號變到最右邊！",
      hint: "row-reverse 讓項目水平排列但順序相反。",
      tip: "💡 reverse = 反轉，row-reverse = 水平反向",
      learnedText: "flex-direction: row-reverse 水平反向排列"
    },
    {
      id: 3, title: "倒掛金鉤", astronautCount: 3, properties: ["flex-direction"],
      target: { "flex-direction": "column-reverse" },
      description: "垂直排列但順序反過來，1號在最下面！",
      hint: "column-reverse 讓項目垂直排列但順序從下到上。",
      tip: "💡 column-reverse = 垂直反向（從下往上）",
      learnedText: "flex-direction: column-reverse 垂直反向排列"
    },
    {
      id: 4, title: "垂直置中", astronautCount: 3, properties: ["flex-direction", "align-items"],
      target: { "flex-direction": "column", "align-items": "center" },
      description: "垂直排列，並讓太空人水平置中！",
      hint: "當 flex-direction 是 column 時，align-items 控制的是水平對齊！",
      tip: "💡 方向改變後，主軸和交叉軸會互換！",
      learnedText: "column 模式下 align-items 控制水平對齊"
    },
    {
      id: 5, title: "底部集結", astronautCount: 3, properties: ["flex-direction", "justify-content"],
      target: { "flex-direction": "column", "justify-content": "flex-end" },
      description: "垂直排列，並讓太空人集中在底部！",
      hint: "垂直排列時，justify-content 控制垂直方向的位置。",
      tip: "💡 column 模式下，justify-content 控制上下位置",
      learnedText: "column 模式下 justify-content 控制垂直對齊"
    },
    {
      id: 6, title: "右下角集合", astronautCount: 3, properties: ["justify-content", "align-items"],
      target: { "justify-content": "flex-end", "align-items": "flex-end" },
      description: "讓太空人集中到右下角！",
      hint: "justify-content: flex-end 靠右，align-items: flex-end 靠底。",
      tip: "💡 兩個 flex-end = 右下角",
      learnedText: "組合 flex-end 可以定位到角落"
    },
    {
      id: 7, title: "左上角待命", astronautCount: 2, properties: ["justify-content", "align-items"],
      target: { "justify-content": "flex-start", "align-items": "flex-start" },
      description: "讓太空人在左上角待命！",
      hint: "兩個都用 flex-start 就會定位到左上角。",
      tip: "💡 兩個 flex-start = 左上角（起點）",
      learnedText: "組合 flex-start 定位到起點角落"
    },
    {
      id: 8, title: "垂直分散", astronautCount: 4, properties: ["flex-direction", "justify-content"],
      target: { "flex-direction": "column", "justify-content": "space-between" },
      description: "垂直排列，且頭尾在容器的上下邊緣！",
      hint: "先用 column 垂直排列，再用 space-between 分散到兩端。",
      tip: "💡 垂直方向的 space-between 會貼上下邊緣",
      learnedText: "垂直方向也能使用 space-between"
    },
    {
      id: 9, title: "反向靠底", astronautCount: 3, properties: ["flex-direction", "align-items"],
      target: { "flex-direction": "row-reverse", "align-items": "flex-end" },
      description: "水平反向排列，且全部靠底部！",
      hint: "row-reverse 反向水平，align-items: flex-end 靠底。",
      tip: "💡 順序反了，但垂直位置可以獨立控制",
      learnedText: "可以同時控制方向和對齊"
    },
    {
      id: 10, title: "垂直居中分散", astronautCount: 4, properties: ["flex-direction", "justify-content", "align-items"],
      target: { "flex-direction": "column", "justify-content": "space-around", "align-items": "center" },
      description: "中級最終關！垂直排列、水平置中、均勻分散！",
      hint: "三個屬性配合：column 垂直、space-around 分散、center 水平置中。",
      tip: "💡 三屬性組合可以創造複雜佈局",
      learnedText: "恭喜完成中級！你已能組合多個屬性"
    }
  ],
  advanced: [
    {
      id: 1, title: "自動換行", astronautCount: 6, properties: ["flex-wrap"],
      target: { "flex-wrap": "wrap" },
      description: "太空人太多了！讓他們自動換到下一行！",
      hint: "flex-wrap: wrap 讓項目在容器寬度不夠時自動換行。",
      tip: "💡 wrap = 包裹、換行，讓內容自動折到下一行",
      learnedText: "flex-wrap: wrap 啟用自動換行"
    },
    {
      id: 2, title: "反向換行", astronautCount: 6, properties: ["flex-wrap"],
      target: { "flex-wrap": "wrap-reverse" },
      description: "換行但從下往上排列！",
      hint: "wrap-reverse 會換行，但新行出現在上方而不是下方。",
      tip: "💡 wrap-reverse = 換行但方向相反",
      learnedText: "flex-wrap: wrap-reverse 反向換行"
    },
    {
      id: 3, title: "換行置中", astronautCount: 6, properties: ["flex-wrap", "justify-content"],
      target: { "flex-wrap": "wrap", "justify-content": "center" },
      description: "自動換行，且每行都置中對齊！",
      hint: "wrap 換行，justify-content: center 讓每一行都置中。",
      tip: "💡 換行後每一行都會套用 justify-content",
      learnedText: "換行後 justify-content 影響每一行"
    },
    {
      id: 4, title: "換行分散", astronautCount: 8, properties: ["flex-wrap", "justify-content"],
      target: { "flex-wrap": "wrap", "justify-content": "space-between" },
      description: "自動換行，每行兩端對齊！",
      hint: "wrap 加上 space-between，每一行都會兩端對齊。",
      tip: "💡 space-between 讓每行的項目貼到左右邊緣",
      learnedText: "換行配合 space-between 非常實用"
    },
    {
      id: 5, title: "垂直換行", astronautCount: 6, properties: ["flex-direction", "flex-wrap"],
      target: { "flex-direction": "column", "flex-wrap": "wrap" },
      description: "垂直排列且自動換到下一列！",
      hint: "column 垂直排列，wrap 讓滿了之後換到右邊新列。",
      tip: "💡 垂直方向的 wrap 會換到右邊新列",
      learnedText: "垂直方向也可以使用 wrap"
    },
    {
      id: 6, title: "右上角換行", astronautCount: 6, properties: ["flex-wrap", "justify-content", "align-items"],
      target: { "flex-wrap": "wrap", "justify-content": "flex-end", "align-items": "flex-start" },
      description: "換行、靠右、靠頂部！",
      hint: "wrap 換行、flex-end 靠右、flex-start（align）靠頂。",
      tip: "💡 三屬性組合定位換行內容的位置",
      learnedText: "可以精確控制換行內容的位置"
    },
    {
      id: 7, title: "垂直反向換行置中", astronautCount: 6, properties: ["flex-direction", "flex-wrap", "align-items"],
      target: { "flex-direction": "column-reverse", "flex-wrap": "wrap", "align-items": "center" },
      description: "垂直反向、自動換行、水平置中！",
      hint: "column-reverse 反向垂直、wrap 換行、center（align）水平置中。",
      tip: "💡 方向和換行可以自由組合",
      learnedText: "flex-direction 和 wrap 組合創造更多可能"
    },
    {
      id: 8, title: "滿版分散", astronautCount: 9, properties: ["flex-wrap", "justify-content", "align-items"],
      target: { "flex-wrap": "wrap", "justify-content": "space-evenly", "align-items": "center" },
      description: "大量太空人！換行、均勻分散、垂直置中！",
      hint: "wrap 換行、space-evenly 均勻分散、center 垂直置中。",
      tip: "💡 這是常見的網格式佈局技巧",
      learnedText: "這種組合常用於卡片式網格佈局"
    },
    {
      id: 9, title: "複雜編隊 A", astronautCount: 8, properties: ["flex-direction", "flex-wrap", "justify-content"],
      target: { "flex-direction": "row-reverse", "flex-wrap": "wrap-reverse", "justify-content": "space-around" },
      description: "反向水平、反向換行、環繞分散！",
      hint: "row-reverse 水平反向、wrap-reverse 反向換行、space-around 環繞。",
      tip: "💡 多個 reverse 會創造有趣的排列效果",
      learnedText: "多重反向創造特殊佈局效果"
    },
    {
      id: 10, title: "終極救援", astronautCount: 9, properties: ["flex-direction", "flex-wrap", "justify-content", "align-items"],
      target: { "flex-direction": "row", "flex-wrap": "wrap", "justify-content": "space-between", "align-items": "center" },
      description: "高級最終關！掌握所有四個屬性！水平換行、兩端對齊、垂直置中！",
      hint: "row 水平、wrap 換行、space-between 兩端、center 垂直置中。這是最常用的響應式佈局！",
      tip: "💡 恭喜！這是實際開發中最常用的 Flexbox 組合之一",
      learnedText: "恭喜完成所有關卡！你已精通 Flexbox！"
    }
  ]
};

// 屬性選項
const propertyOptions = {
  "justify-content": ["flex-start", "flex-end", "center", "space-between", "space-around", "space-evenly"],
  "align-items": ["flex-start", "flex-end", "center", "stretch"],
  "flex-direction": ["row", "row-reverse", "column", "column-reverse"],
  "flex-wrap": ["nowrap", "wrap", "wrap-reverse"]
};

// 難度名稱對照
const difficultyNames = {
  beginner: "初級",
  intermediate: "中級", 
  advanced: "高級"
};

// ===== 遊戲狀態 =====
let currentDifficulty = "beginner";
let currentLevelIndex = 0;
let userValues = {};
let cheatsheetOpen = false;

// ===== DOM 元素 =====
const startScreen = document.getElementById('start-screen');
const difficultyScreen = document.getElementById('difficulty-screen');
const gameScreen = document.getElementById('game-screen');

const startBtn = document.getElementById('start-btn');
const backToStartBtn = document.getElementById('back-to-start');
const backToDifficultyBtn = document.getElementById('back-to-difficulty');
const difficultyCards = document.querySelectorAll('.difficulty-card');

const applyBtn = document.getElementById('apply-btn');
const hintBtn = document.getElementById('hint-btn');
const resetBtn = document.getElementById('reset-btn');
const nextLevelBtn = document.getElementById('next-level-btn');
const restartBtn = document.getElementById('restart-btn');
const nextDifficultyBtn = document.getElementById('next-difficulty-btn');
const closeHintBtn = document.getElementById('close-hint-btn');

const difficultyBadge = document.getElementById('difficulty-badge');
const currentLevelEl = document.getElementById('current-level');
const missionTitle = document.getElementById('mission-title');
const progressFill = document.getElementById('progress-fill');
const targetContainer = document.getElementById('target-container');
const rescuePod = document.getElementById('rescue-pod');
const propertyInputs = document.getElementById('property-inputs');
const feedback = document.getElementById('feedback');
const hintText = document.getElementById('hint-text');

const successModal = document.getElementById('success-modal');
const completeModal = document.getElementById('complete-modal');
const hintModal = document.getElementById('hint-modal');
const successMessage = document.getElementById('success-message');
const learnedProperty = document.getElementById('learned-property');
const hintContent = document.getElementById('hint-content');
const hintTip = document.getElementById('hint-tip');
const skillsList = document.getElementById('skills-list');
const completeTitle = document.getElementById('complete-title');
const completeDesc = document.getElementById('complete-desc');

const cheatsheetToggle = document.getElementById('cheatsheet-toggle');
const cheatsheetContent = document.getElementById('cheatsheet-content');
const toggleIcon = document.getElementById('toggle-icon');
const tabBtns = document.querySelectorAll('.tab-btn');

// ===== 事件監聽 =====
startBtn.addEventListener('click', showDifficultyScreen);
backToStartBtn.addEventListener('click', showStartScreen);
backToDifficultyBtn.addEventListener('click', showDifficultyScreen);

difficultyCards.forEach(card => {
  card.addEventListener('click', () => {
    currentDifficulty = card.dataset.difficulty;
    startGame();
  });
});

applyBtn.addEventListener('click', applyCode);
hintBtn.addEventListener('click', showHint);
resetBtn.addEventListener('click', resetLevel);
nextLevelBtn.addEventListener('click', nextLevel);
restartBtn.addEventListener('click', restartCurrentDifficulty);
nextDifficultyBtn.addEventListener('click', goToNextDifficulty);
closeHintBtn.addEventListener('click', () => hintModal.classList.remove('active'));

cheatsheetToggle.addEventListener('click', toggleCheatsheet);
tabBtns.forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// ===== 畫面切換 =====
function showStartScreen() {
  startScreen.classList.add('active');
  difficultyScreen.classList.remove('active');
  gameScreen.classList.remove('active');
}

function showDifficultyScreen() {
  startScreen.classList.remove('active');
  difficultyScreen.classList.add('active');
  gameScreen.classList.remove('active');
}

function startGame() {
  difficultyScreen.classList.remove('active');
  gameScreen.classList.add('active');
  currentLevelIndex = 0;
  loadLevel();
}

// ===== 遊戲函數 =====
function loadLevel() {
  const levels = allLevels[currentDifficulty];
  const level = levels[currentLevelIndex];
  
  // 更新頂部資訊
  difficultyBadge.textContent = difficultyNames[currentDifficulty];
  difficultyBadge.className = `level-badge ${currentDifficulty}`;
  currentLevelEl.textContent = level.id;
  missionTitle.textContent = level.title;
  progressFill.style.width = `${(currentLevelIndex / levels.length) * 100}%`;
  hintText.textContent = level.description;
  
  // 重置用戶輸入值
  userValues = {};
  level.properties.forEach(prop => {
    userValues[prop] = propertyOptions[prop][0];
  });
  
  // 生成目標區和玩家區太空人
  renderAstronauts(targetContainer, level.astronautCount, true, level.target);
  renderAstronauts(rescuePod, level.astronautCount, false, {});
  
  // 重置救援艙樣式
  rescuePod.style.flexDirection = '';
  rescuePod.style.justifyContent = '';
  rescuePod.style.alignItems = '';
  rescuePod.style.flexWrap = '';
  
  // 生成屬性輸入
  renderPropertyInputs(level.properties);
  
  // 重置反饋
  feedback.classList.remove('show', 'error', 'success');
}

function renderAstronauts(container, count, isTarget, styles) {
  container.innerHTML = '';
  
  for (let i = 0; i < count; i++) {
    const astronaut = document.createElement('div');
    astronaut.className = `astronaut${isTarget ? ' target-astronaut' : ''}`;
    astronaut.innerHTML = '<span class="astronaut-emoji">👨‍🚀</span>';
    container.appendChild(astronaut);
  }
  
  // 應用樣式
  if (isTarget) {
    Object.keys(styles).forEach(prop => {
      container.style[toCamelCase(prop)] = styles[prop];
    });
  }
}

function renderPropertyInputs(properties) {
  propertyInputs.innerHTML = '';
  
  properties.forEach(prop => {
    const inputDiv = document.createElement('div');
    inputDiv.className = 'property-input';
    
    const label = document.createElement('label');
    label.textContent = `${prop}:`;
    
    const select = document.createElement('select');
    select.id = `input-${prop}`;
    select.dataset.property = prop;
    
    propertyOptions[prop].forEach(option => {
      const opt = document.createElement('option');
      opt.value = option;
      opt.textContent = option + ';';
      select.appendChild(opt);
    });
    
    select.addEventListener('change', (e) => {
      userValues[prop] = e.target.value;
      previewCode();
    });
    
    inputDiv.appendChild(label);
    inputDiv.appendChild(select);
    propertyInputs.appendChild(inputDiv);
  });
}

function previewCode() {
  Object.keys(userValues).forEach(prop => {
    rescuePod.style[toCamelCase(prop)] = userValues[prop];
  });
}

function applyCode() {
  const levels = allLevels[currentDifficulty];
  const level = levels[currentLevelIndex];
  
  // 應用樣式
  Object.keys(userValues).forEach(prop => {
    rescuePod.style[toCamelCase(prop)] = userValues[prop];
  });
  
  // 檢查答案
  let isCorrect = true;
  for (const prop in level.target) {
    if (userValues[prop] !== level.target[prop]) {
      isCorrect = false;
      break;
    }
  }
  
  if (isCorrect) {
    showSuccess();
  } else {
    feedback.textContent = '還不太對，再試試看！觀察目標陣型的排列方式。';
    feedback.classList.add('show', 'error');
    feedback.classList.remove('success');
    
    rescuePod.style.animation = 'shake 0.5s ease';
    setTimeout(() => { rescuePod.style.animation = ''; }, 500);
  }
}

function showSuccess() {
  const levels = allLevels[currentDifficulty];
  const level = levels[currentLevelIndex];
  
  feedback.textContent = '太棒了！救援成功！';
  feedback.classList.add('show', 'success');
  feedback.classList.remove('error');
  
  setTimeout(() => {
    successMessage.textContent = `你成功使用 Flexbox 救回了 ${level.astronautCount} 位太空人！`;
    
    let codeText = '<code>.rescue-pod</code> {\n';
    for (const prop in level.target) {
      codeText += `  <code>${prop}: ${level.target[prop]};</code>\n`;
    }
    codeText += '}';
    learnedProperty.innerHTML = `<pre>${codeText}</pre><p class="learned-desc">${level.learnedText}</p>`;
    
    successModal.classList.add('active');
  }, 500);
}

function showHint() {
  const levels = allLevels[currentDifficulty];
  const level = levels[currentLevelIndex];
  hintContent.textContent = level.hint;
  hintTip.textContent = level.tip;
  hintModal.classList.add('active');
}

function resetLevel() {
  loadLevel();
}

function nextLevel() {
  successModal.classList.remove('active');
  const levels = allLevels[currentDifficulty];
  
  if (currentLevelIndex < levels.length - 1) {
    currentLevelIndex++;
    loadLevel();
  } else {
    showComplete();
  }
}

function showComplete() {
  const diffName = difficultyNames[currentDifficulty];
  completeTitle.textContent = `${diffName}任務完成！`;
  
  // 根據難度顯示不同內容
  const skillsMap = {
    beginner: ['justify-content - 主軸對齊', 'align-items - 交叉軸對齊', '雙屬性組合運用'],
    intermediate: ['flex-direction - 排列方向', '方向改變後軸的變化', '三屬性組合運用'],
    advanced: ['flex-wrap - 換行控制', '四屬性完整運用', '響應式佈局技巧']
  };
  
  skillsList.innerHTML = '';
  skillsMap[currentDifficulty].forEach(skill => {
    const li = document.createElement('li');
    li.textContent = skill;
    skillsList.appendChild(li);
  });
  
  // 判斷是否還有下一個難度
  const difficultyOrder = ['beginner', 'intermediate', 'advanced'];
  const currentIndex = difficultyOrder.indexOf(currentDifficulty);
  
  if (currentIndex < difficultyOrder.length - 1) {
    nextDifficultyBtn.style.display = 'inline-flex';
    nextDifficultyBtn.querySelector('span:first-child').textContent = 
      `挑戰${difficultyNames[difficultyOrder[currentIndex + 1]]}難度`;
    completeDesc.textContent = `你已完成${diffName}的所有關卡！準備好挑戰更高難度了嗎？`;
  } else {
    nextDifficultyBtn.style.display = 'none';
    completeDesc.textContent = '恭喜你完成所有難度的挑戰！你已經是 Flexbox 大師了！';
  }
  
  completeModal.classList.add('active');
}

function restartCurrentDifficulty() {
  completeModal.classList.remove('active');
  currentLevelIndex = 0;
  loadLevel();
}

function goToNextDifficulty() {
  completeModal.classList.remove('active');
  const difficultyOrder = ['beginner', 'intermediate', 'advanced'];
  const currentIndex = difficultyOrder.indexOf(currentDifficulty);
  
  if (currentIndex < difficultyOrder.length - 1) {
    currentDifficulty = difficultyOrder[currentIndex + 1];
    currentLevelIndex = 0;
    loadLevel();
  }
}

// ===== 寶典功能 =====
function toggleCheatsheet() {
  cheatsheetOpen = !cheatsheetOpen;
  cheatsheetContent.classList.toggle('open', cheatsheetOpen);
  toggleIcon.textContent = cheatsheetOpen ? '▲' : '▼';
}

function switchTab(tabName) {
  tabBtns.forEach(btn => btn.classList.remove('active'));
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
  
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
  });
  document.getElementById(`tab-${tabName}`).classList.add('active');
}

// ===== 工具函數 =====
function toCamelCase(str) {
  return str.replace(/-([a-z])/g, (g) => g[1].toUpperCase());
}

// 搖晃動畫
const shakeStyle = document.createElement('style');
shakeStyle.textContent = `
  @keyframes shake {
    0%, 100% { transform: translateX(0); }
    20% { transform: translateX(-10px); }
    40% { transform: translateX(10px); }
    60% { transform: translateX(-10px); }
    80% { transform: translateX(10px); }
  }
`;
document.head.appendChild(shakeStyle);
